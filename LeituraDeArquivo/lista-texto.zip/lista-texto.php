<?php

$curso = file_get_contents('texto.txt');

echo $curso;